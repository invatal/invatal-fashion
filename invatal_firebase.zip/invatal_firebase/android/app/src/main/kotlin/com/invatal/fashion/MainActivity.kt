package com.invatal.fashion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
