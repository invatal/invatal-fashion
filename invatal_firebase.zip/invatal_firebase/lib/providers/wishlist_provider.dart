import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

class WishlistProvider extends ChangeNotifier {
  final FirestoreService _fs = FirestoreService();
  Set<String> _wishlistIds = {};

  Set<String> get wishlistIds => _wishlistIds;

  bool isWishlisted(String productId) => _wishlistIds.contains(productId);

  void listenToWishlist() {
    _fs.wishlistStream().listen((ids) {
      _wishlistIds = ids.toSet();
      notifyListeners();
    });
  }

  Future<void> toggle(String productId) async {
    if (_wishlistIds.contains(productId)) {
      await _fs.removeFromWishlist(productId);
      _wishlistIds.remove(productId);
    } else {
      await _fs.addToWishlist(productId);
      _wishlistIds.add(productId);
    }
    notifyListeners();
  }
}