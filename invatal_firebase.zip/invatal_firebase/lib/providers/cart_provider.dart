import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

class CartItem {
  final String id;
  final String productId;
  final String name;
  final double price;
  final String imageUrl;
  final String size;
  final String color;
  int qty;

  CartItem({
    required this.id,
    required this.productId,
    required this.name,
    required this.price,
    required this.imageUrl,
    required this.size,
    required this.color,
    required this.qty,
  });

  double get total => price * qty;

  factory CartItem.fromMap(Map<String, dynamic> m) => CartItem(
    id: m['id'] ?? '',
    productId: m['productId'] ?? '',
    name: m['name'] ?? '',
    price: (m['price'] ?? 0).toDouble(),
    imageUrl: m['imageUrl'] ?? '',
    size: m['size'] ?? 'M',
    color: m['color'] ?? 'Red',
    qty: m['qty'] ?? 1,
  );
}

class CartProvider extends ChangeNotifier {
  final FirestoreService _fs = FirestoreService();
  List<CartItem> _items = [];
  bool _loading = false;

  List<CartItem> get items => _items;
  bool get loading => _loading;
  int get itemCount => _items.fold(0, (s, i) => s + i.qty);
  double get subtotal => _items.fold(0, (s, i) => s + i.total);

  void listenToCart() {
    _fs.cartStream().listen((maps) {
      _items = maps.map((m) => CartItem.fromMap(m)).toList();
      notifyListeners();
    });
  }

  Future<void> addItem({
    required String productId,
    required String name,
    required double price,
    required String imageUrl,
    required String size,
    required String color,
    int qty = 1,
  }) async {
    await _fs.addToCart(
      productId: productId, name: name, price: price,
      imageUrl: imageUrl, size: size, color: color, qty: qty,
    );
  }

  Future<void> updateQty(String cartItemId, int qty) async {
    await _fs.updateCartQty(cartItemId, qty);
  }

  Future<void> removeItem(String cartItemId) async {
    await _fs.removeCartItem(cartItemId);
  }

  Future<void> clearCart() async {
    await _fs.clearCart();
    _items = [];
    notifyListeners();
  }
}