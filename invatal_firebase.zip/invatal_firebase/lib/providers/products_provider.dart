import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/firestore_service.dart';

class ProductsProvider extends ChangeNotifier {
  final FirestoreService _fs = FirestoreService();
  List<Product> _products = [];
  bool _loading = false;
  String? _error;

  List<Product> get products => _products;
  bool get loading => _loading;
  String? get error => _error;

  Future<void> loadProducts() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      // Seed if needed, then fetch
      await _fs.seedProducts();
      _products = await _fs.getProducts();
    } catch (e) {
      // Fall back to local sample products
      _products = sampleProducts;
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }

  List<Product> getByCategory(String category) {
    if (category == 'All') return _products;
    return _products.where((p) => p.category == category).toList();
  }
}