import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/product.dart';
import '../models/order_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get _uid => _auth.currentUser?.uid;

  // ── PRODUCTS ──────────────────────────────────────────────────────────────

  // Seed sample products to Firestore (call once on first run)
  Future<void> seedProducts() async {
    final col = _db.collection('products');
    final snap = await col.limit(1).get();
    if (snap.docs.isNotEmpty) return; // already seeded
    final batch = _db.batch();
    for (final p in sampleProducts) {
      batch.set(col.doc(p.id), p.toMap());
    }
    await batch.commit();
  }

  // Fetch all products
  Future<List<Product>> getProducts() async {
    final snap = await _db.collection('products').get();
    return snap.docs.map((d) => Product.fromMap(d.data())).toList();
  }

  // Fetch products by category
  Future<List<Product>> getProductsByCategory(String category) async {
    final snap = await _db.collection('products')
        .where('category', isEqualTo: category).get();
    return snap.docs.map((d) => Product.fromMap(d.data())).toList();
  }

  // Real-time products stream
  Stream<List<Product>> productsStream() {
    return _db.collection('products').snapshots().map(
        (snap) => snap.docs.map((d) => Product.fromMap(d.data())).toList());
  }

  // ── WISHLIST ──────────────────────────────────────────────────────────────

  Future<void> addToWishlist(String productId) async {
    if (_uid == null) return;
    await _db.collection('users').doc(_uid).collection('wishlist').doc(productId).set({
      'productId': productId,
      'addedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> removeFromWishlist(String productId) async {
    if (_uid == null) return;
    await _db.collection('users').doc(_uid).collection('wishlist').doc(productId).delete();
  }

  Stream<List<String>> wishlistStream() {
    if (_uid == null) return const Stream.empty();
    return _db.collection('users').doc(_uid).collection('wishlist')
        .snapshots().map((s) => s.docs.map((d) => d.id).toList());
  }

  Future<List<String>> getWishlistIds() async {
    if (_uid == null) return [];
    final snap = await _db.collection('users').doc(_uid).collection('wishlist').get();
    return snap.docs.map((d) => d.id).toList();
  }

  // ── CART ──────────────────────────────────────────────────────────────────

  Future<void> addToCart({
    required String productId,
    required String name,
    required double price,
    required String imageUrl,
    required String size,
    required String color,
    int qty = 1,
  }) async {
    if (_uid == null) return;
    final cartRef = _db.collection('users').doc(_uid).collection('cart').doc('${productId}_$size');
    final existing = await cartRef.get();
    if (existing.exists) {
      await cartRef.update({'qty': FieldValue.increment(qty)});
    } else {
      await cartRef.set({
        'productId': productId,
        'name': name,
        'price': price,
        'imageUrl': imageUrl,
        'size': size,
        'color': color,
        'qty': qty,
        'addedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> updateCartQty(String cartItemId, int qty) async {
    if (_uid == null) return;
    if (qty <= 0) {
      await _db.collection('users').doc(_uid).collection('cart').doc(cartItemId).delete();
    } else {
      await _db.collection('users').doc(_uid).collection('cart')
          .doc(cartItemId).update({'qty': qty});
    }
  }

  Future<void> removeCartItem(String cartItemId) async {
    if (_uid == null) return;
    await _db.collection('users').doc(_uid).collection('cart').doc(cartItemId).delete();
  }

  Future<void> clearCart() async {
    if (_uid == null) return;
    final snap = await _db.collection('users').doc(_uid).collection('cart').get();
    final batch = _db.batch();
    for (final doc in snap.docs) batch.delete(doc.reference);
    await batch.commit();
  }

  Stream<List<Map<String, dynamic>>> cartStream() {
    if (_uid == null) return const Stream.empty();
    return _db.collection('users').doc(_uid).collection('cart')
        .orderBy('addedAt')
        .snapshots()
        .map((s) => s.docs.map((d) => {'id': d.id, ...d.data()}).toList());
  }

  // ── ORDERS ────────────────────────────────────────────────────────────────

  Future<String> placeOrder(OrderModel order) async {
    if (_uid == null) throw Exception('User not logged in');
    final ref = _db.collection('orders').doc();
    final o = order.copyWith(id: ref.id, userId: _uid!);
    await ref.set(o.toMap());
    // Also save under user
    await _db.collection('users').doc(_uid).collection('orders').doc(ref.id).set({'orderId': ref.id});
    await clearCart();
    return ref.id;
  }

  Stream<List<OrderModel>> ordersStream() {
    if (_uid == null) return const Stream.empty();
    return _db.collection('orders')
        .where('userId', isEqualTo: _uid)
        .snapshots()
        .map((s) {
          final orders = s.docs.map((d) => OrderModel.fromMap(d.data())).toList();
          // Sort client-side to avoid needing a Firestore composite index
          orders.sort((a, b) {
            if (a.createdAt == null && b.createdAt == null) return 0;
            if (a.createdAt == null) return 1;
            if (b.createdAt == null) return -1;
            return b.createdAt!.compareTo(a.createdAt!);
          });
          return orders;
        });
  }

  Future<List<OrderModel>> getOrders() async {
    if (_uid == null) return [];
    final snap = await _db.collection('orders')
        .where('userId', isEqualTo: _uid)
        .get();
    final orders = snap.docs.map((d) => OrderModel.fromMap(d.data())).toList();
    orders.sort((a, b) {
      if (a.createdAt == null && b.createdAt == null) return 0;
      if (a.createdAt == null) return 1;
      if (b.createdAt == null) return -1;
      return b.createdAt!.compareTo(a.createdAt!);
    });
    return orders;
  }
}