class Product {
  final String id;
  final String name;
  final String category;
  final double price;
  final double? oldPrice;
  final String imageUrl;
  final String description;
  final double rating;
  final int reviewCount;
  final bool isNew;
  final List<String> sizes;

  Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    this.oldPrice,
    required this.imageUrl,
    required this.description,
    this.rating = 4.5,
    this.reviewCount = 0,
    this.isNew = false,
    this.sizes = const ['XS', 'S', 'M', 'L', 'XL'],
  });

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      category: map['category'] ?? '',
      price: (map['price'] ?? 0).toDouble(),
      oldPrice: map['oldPrice']?.toDouble(),
      imageUrl: map['imageUrl'] ?? '',
      description: map['description'] ?? '',
      rating: (map['rating'] ?? 4.5).toDouble(),
      reviewCount: map['reviewCount'] ?? 0,
      isNew: map['isNew'] ?? false,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id, 'name': name, 'category': category,
        'price': price, 'oldPrice': oldPrice,
        'imageUrl': imageUrl, 'description': description,
        'rating': rating, 'reviewCount': reviewCount, 'isNew': isNew,
      };
}

final List<Product> sampleProducts = [
  Product(
    id: '1',
    name: 'Floral Midi Dress',
    category: 'Dresses',
    price: 3500,
    oldPrice: 4200,
    imageUrl: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=500&fit=crop',
    description: 'A beautiful floral midi dress perfect for any occasion. Made from breathable cotton blend with a flattering A-line silhouette.',
    rating: 4.8, reviewCount: 128, isNew: true,
  ),
  Product(
    id: '2',
    name: 'Classic White Top',
    category: 'Tops',
    price: 1800,
    imageUrl: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=500&fit=crop',
    description: 'A timeless classic white top that pairs perfectly with any bottom. Lightweight and comfortable for everyday wear.',
    rating: 4.3, reviewCount: 75,
  ),
  Product(
    id: '3',
    name: 'High Waist Jeans',
    category: 'Bottoms',
    price: 4200,
    oldPrice: 5500,
    imageUrl: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=500&fit=crop',
    description: 'Stylish high-waist jeans with a perfect fit. Stretchy denim blend for maximum comfort throughout the day.',
    rating: 4.9, reviewCount: 210, isNew: true,
  ),
  Product(
    id: '4',
    name: 'White Sneakers',
    category: 'Shoes',
    price: 8500,
    imageUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=500&fit=crop',
    description: 'Clean, minimalist white sneakers that go with everything. Premium synthetic leather with cushioned sole.',
    rating: 4.5, reviewCount: 93,
    sizes: ['36', '37', '38', '39', '40', '41'],
  ),
  Product(
    id: '5',
    name: 'Evening Gown',
    category: 'Dresses',
    price: 12000,
    oldPrice: 15000,
    imageUrl: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&h=500&fit=crop',
    description: 'Elegant evening gown perfect for formal events. Floor-length silhouette with delicate embellishments.',
    rating: 5.0, reviewCount: 42,
  ),
  Product(
    id: '6',
    name: 'Leather Handbag',
    category: 'Accessories',
    price: 6500,
    imageUrl: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&h=500&fit=crop',
    description: 'Premium faux leather handbag with spacious interior. Features multiple compartments and adjustable strap.',
    rating: 4.7, reviewCount: 156,
    sizes: ['One Size'],
  ),
];
