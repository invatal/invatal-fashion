import 'package:cloud_firestore/cloud_firestore.dart';

class OrderItem {
  final String productId;
  final String name;
  final double price;
  final String imageUrl;
  final int qty;
  final String size;
  final String color;

  OrderItem({
    required this.productId,
    required this.name,
    required this.price,
    required this.imageUrl,
    required this.qty,
    required this.size,
    required this.color,
  });

  factory OrderItem.fromMap(Map<String, dynamic> m) => OrderItem(
    productId: m['productId'] ?? '',
    name: m['name'] ?? '',
    price: (m['price'] ?? 0).toDouble(),
    imageUrl: m['imageUrl'] ?? '',
    qty: m['qty'] ?? 1,
    size: m['size'] ?? 'M',
    color: m['color'] ?? 'Red',
  );

  Map<String, dynamic> toMap() => {
    'productId': productId, 'name': name, 'price': price,
    'imageUrl': imageUrl, 'qty': qty, 'size': size, 'color': color,
  };
}

class OrderModel {
  final String id;
  final String userId;
  final List<OrderItem> items;
  final double subtotal;
  final double deliveryFee;
  final double total;
  final String status;
  final String deliveryAddress;
  final String city;
  final String phone;
  final String paymentMethod;
  final DateTime? createdAt;

  OrderModel({
    required this.id,
    required this.userId,
    required this.items,
    required this.subtotal,
    required this.deliveryFee,
    required this.total,
    required this.status,
    required this.deliveryAddress,
    required this.city,
    required this.phone,
    required this.paymentMethod,
    this.createdAt,
  });

  OrderModel copyWith({
    String? id,
    String? userId,
    List<OrderItem>? items,
    double? subtotal,
    double? deliveryFee,
    double? total,
    String? status,
    String? deliveryAddress,
    String? city,
    String? phone,
    String? paymentMethod,
    DateTime? createdAt,
  }) => OrderModel(
    id: id ?? this.id,
    userId: userId ?? this.userId,
    items: items ?? this.items,
    subtotal: subtotal ?? this.subtotal,
    deliveryFee: deliveryFee ?? this.deliveryFee,
    total: total ?? this.total,
    status: status ?? this.status,
    deliveryAddress: deliveryAddress ?? this.deliveryAddress,
    city: city ?? this.city,
    phone: phone ?? this.phone,
    paymentMethod: paymentMethod ?? this.paymentMethod,
    createdAt: createdAt ?? this.createdAt,
  );

  factory OrderModel.fromMap(Map<String, dynamic> m) => OrderModel(
    id: m['id'] ?? '',
    userId: m['userId'] ?? '',
    items: (m['items'] as List<dynamic>? ?? [])
        .map((i) => OrderItem.fromMap(i as Map<String, dynamic>)).toList(),
    subtotal: (m['subtotal'] ?? 0).toDouble(),
    deliveryFee: (m['deliveryFee'] ?? 0).toDouble(),
    total: (m['total'] ?? 0).toDouble(),
    status: m['status'] ?? 'Processing',
    deliveryAddress: m['deliveryAddress'] ?? '',
    city: m['city'] ?? '',
    phone: m['phone'] ?? '',
    paymentMethod: m['paymentMethod'] ?? '',
    createdAt: m['createdAt'] is Timestamp
        ? (m['createdAt'] as Timestamp).toDate()
        : null,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'userId': userId,
    'items': items.map((i) => i.toMap()).toList(),
    'subtotal': subtotal,
    'deliveryFee': deliveryFee,
    'total': total,
    'status': status,
    'deliveryAddress': deliveryAddress,
    'city': city,
    'phone': phone,
    'paymentMethod': paymentMethod,
    'createdAt': FieldValue.serverTimestamp(),
  };
}