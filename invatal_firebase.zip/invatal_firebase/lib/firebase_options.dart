import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDv-d5I34JuWoWYloLnXI6gmrQoJMoalow',
    appId: '1:1081593317041:android:c47a1e2ce8862f27784490',
    messagingSenderId: '1081593317041',
    projectId: 'invatal-fashion',
    storageBucket: 'invatal-fashion.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDv-d5I34JuWoWYloLnXI6gmrQoJMoalow',
    appId: '1:1081593317041:ios:c47a1e2ce8862f27784490',
    messagingSenderId: '1081593317041',
    projectId: 'invatal-fashion',
    storageBucket: 'invatal-fashion.firebasestorage.app',
    iosBundleId: 'com.invatal.fashion',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDv-d5I34JuWoWYloLnXI6gmrQoJMoalow',
    appId: '1:1081593317041:web:c47a1e2ce8862f27784490',
    messagingSenderId: '1081593317041',
    projectId: 'invatal-fashion',
    storageBucket: 'invatal-fashion.firebasestorage.app',
    authDomain: 'invatal-fashion.firebaseapp.com',
  );
}
