import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../utils/app_theme.dart';
import '../providers/auth_provider.dart' as app_auth;
import '../providers/wishlist_provider.dart';
import 'login_screen.dart';
import 'order_history_screen.dart';
import 'wishlist_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final options = [
      {'icon': Icons.shopping_bag_outlined, 'label': 'My Orders',        'screen': const OrderHistoryScreen()},
      {'icon': Icons.favorite_outline,      'label': 'Wishlist',          'screen': const WishlistScreen()},
      {'icon': Icons.location_on_outlined,  'label': 'Saved Addresses',   'screen': null},
      {'icon': Icons.credit_card_outlined,  'label': 'Payment Methods',   'screen': null},
      {'icon': Icons.notifications_outlined,'label': 'Notifications',     'screen': null},
      {'icon': Icons.settings_outlined,     'label': 'Settings',          'screen': null},
      {'icon': Icons.help_outline,          'label': 'Help & Support',    'screen': null},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        actions: [
          IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          // Header
          Container(
            color: AppColors.primary,
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 28),
            child: Column(children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 3),
                ),
                child: user?.photoURL != null
                    ? ClipOval(child: Image.network(user!.photoURL!, fit: BoxFit.cover))
                    : const Center(child: Text('👩', style: TextStyle(fontSize: 38))),
              ),
              const SizedBox(height: 12),
              Text(
                user?.displayName ?? 'Fashion User',
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 2),
              Text(
                user?.email ?? '',
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 16),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _statWidget('My', 'Orders'),
                Container(width: 1, height: 30, color: Colors.white30,
                    margin: const EdgeInsets.symmetric(horizontal: 24)),
                Consumer<WishlistProvider>(
                  builder: (_, w, __) => _statWidget('${w.wishlistIds.length}', 'Wishlist'),
                ),
                Container(width: 1, height: 30, color: Colors.white30,
                    margin: const EdgeInsets.symmetric(horizontal: 24)),
                _statWidget('0', 'Reviews'),
              ]),
            ]),
          ),
          // Menu options
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFF0F0F0)),
            ),
            child: Column(children: [
              ...options.asMap().entries.map((entry) {
                final i = entry.key;
                final opt = entry.value;
                return Column(children: [
                  ListTile(
                    leading: Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                          color: AppColors.primaryLight,
                          borderRadius: BorderRadius.circular(10)),
                      child: Icon(opt['icon'] as IconData, color: AppColors.primary, size: 20),
                    ),
                    title: Text(opt['label'] as String,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                    trailing: const Icon(Icons.chevron_right, color: AppColors.greyText),
                    onTap: () {
                      final screen = opt['screen'];
                      if (screen != null) {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => screen as Widget));
                      }
                    },
                  ),
                  if (i < options.length - 1)
                    const Divider(height: 1, indent: 66),
                ]);
              }),
            ]),
          ),
          // Logout
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            child: OutlinedButton.icon(
              onPressed: () async {
                await context.read<app_auth.AuthProvider>().signOut();
                if (context.mounted) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (_) => false,
                  );
                }
              },
              icon: const Icon(Icons.logout, color: AppColors.primary),
              label: const Text('Logout',
                  style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600)),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                side: const BorderSide(color: AppColors.primary),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  static Widget _statWidget(String value, String label) {
    return Column(children: [
      Text(value,
          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
    ]);
  }
}
