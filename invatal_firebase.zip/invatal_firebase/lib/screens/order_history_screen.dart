
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/app_theme.dart';
import '../models/order_model.dart';
import '../services/firestore_service.dart';

class OrderHistoryScreen extends StatefulWidget {
  const OrderHistoryScreen({super.key});
  @override
  State<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends State<OrderHistoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _fs = FirestoreService();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() { _tabController.dispose(); super.dispose(); }

  Color _statusColor(String status) {
    switch (status) {
      case 'Delivered': return AppColors.success;
      case 'Processing': return AppColors.primary;
      case 'Cancelled': return Colors.grey;
      default: return AppColors.greyText;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Orders'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          tabs: const [Tab(text: 'All'), Tab(text: 'Pending'), Tab(text: 'Delivered'), Tab(text: 'Cancelled')],
        ),
      ),
      body: StreamBuilder<List<OrderModel>>(
        stream: _fs.ordersStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}',
                style: const TextStyle(color: AppColors.greyText)));
          }
          final all = snapshot.data ?? [];
          return TabBarView(
            controller: _tabController,
            children: [
              _OrderList(all),
              _OrderList(all.where((o) => o.status == 'Processing').toList()),
              _OrderList(all.where((o) => o.status == 'Delivered').toList()),
              _OrderList(all.where((o) => o.status == 'Cancelled').toList()),
            ],
          );
        },
      ),
    );
  }

  Widget _OrderList(List<OrderModel> orders) {
    if (orders.isEmpty) return const Center(
        child: Text('No orders found', style: TextStyle(color: AppColors.greyText)));

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: orders.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, i) {
        final order = orders[i];
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFF0F0F0)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))]),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('#${order.id.substring(0, 8).toUpperCase()}',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _statusColor(order.status).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20)),
                child: Text(order.status, style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w600, color: _statusColor(order.status)))),
            ]),
            const SizedBox(height: 6),
            Row(children: [
              Text('${order.items.length} item${order.items.length != 1 ? 's' : ''} · ${order.city}',
                  style: const TextStyle(fontSize: 12, color: AppColors.greyText)),
            ]),
            const Divider(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('LKR ${order.total.toStringAsFixed(0)}',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.primary)),
              TextButton(
                onPressed: () {},
                style: TextButton.styleFrom(
                  backgroundColor: AppColors.primaryLight,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  minimumSize: Size.zero),
                child: Text(order.status == 'Delivered' ? 'Reorder' : 'View Details',
                    style: const TextStyle(color: AppColors.primary, fontSize: 11, fontWeight: FontWeight.w600))),
            ]),
          ]),
        );
      },
    );
  }
}
