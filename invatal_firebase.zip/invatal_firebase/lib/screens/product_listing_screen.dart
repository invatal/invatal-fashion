
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/app_theme.dart';
import '../widgets/product_card.dart';
import '../providers/products_provider.dart';
import 'product_detail_screen.dart';

class ProductListingScreen extends StatefulWidget {
  const ProductListingScreen({super.key});
  @override
  State<ProductListingScreen> createState() => _ProductListingScreenState();
}

class _ProductListingScreenState extends State<ProductListingScreen> {
  String _selectedCategory = 'All';
  final List<String> _categories = ['All', 'Dresses', 'Tops', 'Bottoms', 'Shoes', 'Accessories'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Products'),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: () {}),
          IconButton(icon: const Icon(Icons.tune), onPressed: () {}),
        ],
      ),
      body: Column(children: [
        SizedBox(
          height: 50,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: _categories.length,
            itemBuilder: (context, i) {
              final cat = _categories[i];
              final isActive = cat == _selectedCategory;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: () => setState(() => _selectedCategory = cat),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: isActive ? AppColors.primary : Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: isActive ? AppColors.primary : const Color(0xFFE0E0E0))),
                    child: Text(cat, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500,
                        color: isActive ? Colors.white : AppColors.darkText)))));
            }),
        ),
        Expanded(
          child: Consumer<ProductsProvider>(
            builder: (_, prods, __) {
              if (prods.loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
              final filtered = prods.getByCategory(_selectedCategory);
              if (filtered.isEmpty) return const Center(
                  child: Text('No products found', style: TextStyle(color: AppColors.greyText)));
              return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, childAspectRatio: 0.68, crossAxisSpacing: 12, mainAxisSpacing: 12),
                itemCount: filtered.length,
                itemBuilder: (context, i) => ProductCard(
                  product: filtered[i],
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => ProductDetailScreen(product: filtered[i])))));
            }),
        ),
      ]),
    );
  }
}
