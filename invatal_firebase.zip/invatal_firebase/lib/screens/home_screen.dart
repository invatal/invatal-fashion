import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/app_theme.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';
import '../providers/products_provider.dart';
import '../providers/cart_provider.dart';
import 'product_listing_screen.dart';
import 'product_detail_screen.dart';
import 'cart_screen.dart';
import 'wishlist_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProductsProvider>().loadProducts();
      context.read<CartProvider>().listenToCart();
    });
  }

  final List<Widget> _pages = const [
    _HomeContent(),
    ProductListingScreen(),
    WishlistScreen(),
    CartScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.greyText,
        type: BottomNavigationBarType.fixed,
        items: [
          const BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: 'Home'),
          const BottomNavigationBarItem(icon: Icon(Icons.shopping_bag_outlined), activeIcon: Icon(Icons.shopping_bag), label: 'Shop'),
          const BottomNavigationBarItem(icon: Icon(Icons.favorite_outline), activeIcon: Icon(Icons.favorite), label: 'Wishlist'),
          BottomNavigationBarItem(
            icon: Consumer<CartProvider>(
              builder: (_, cart, __) => Badge(
                isLabelVisible: cart.itemCount > 0,
                label: Text('${cart.itemCount}'),
                child: const Icon(Icons.shopping_cart_outlined)),
            ),
            activeIcon: Consumer<CartProvider>(
              builder: (_, cart, __) => Badge(
                isLabelVisible: cart.itemCount > 0,
                label: Text('${cart.itemCount}'),
                child: const Icon(Icons.shopping_cart)),
            ),
            label: 'Cart'),
          const BottomNavigationBarItem(icon: Icon(Icons.person_outline), activeIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _HomeContent extends StatelessWidget {
  const _HomeContent();

  @override
  Widget build(BuildContext context) {
    final categories = [
      {'img': 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=104&h=104&fit=crop', 'name': 'Dresses'},
      {'img': 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=104&h=104&fit=crop', 'name': 'Tops'},
      {'img': 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=104&h=104&fit=crop', 'name': 'Jeans'},
      {'img': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=104&h=104&fit=crop', 'name': 'Shoes'},
      {'img': 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=104&h=104&fit=crop', 'name': 'Bags'},
      {'img': 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=104&h=104&fit=crop', 'name': 'Gowns'},
    ];

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true,
            backgroundColor: AppColors.primary,
            title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
              Text('Good morning 👋', style: TextStyle(color: Colors.white70, fontSize: 11)),
              Text('INVATAL FASHION', style: TextStyle(
                  color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2)),
            ]),
            actions: [
              IconButton(icon: const Icon(Icons.notifications_outlined, color: Colors.white), onPressed: () {}),
              Stack(children: [
                IconButton(
                  icon: const Icon(Icons.shopping_cart_outlined, color: Colors.white),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const CartScreen()))),
                Positioned(right: 8, top: 8, child: Consumer<CartProvider>(
                  builder: (_, cart, __) => cart.itemCount > 0
                      ? Container(width: 8, height: 8,
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4)))
                      : const SizedBox.shrink(),
                )),
              ]),
            ],
          ),
          SliverToBoxAdapter(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Search
              Padding(
                padding: const EdgeInsets.all(16),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE0E0E0)),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
                  ),
                  child: Row(children: [
                    const Padding(padding: EdgeInsets.only(left: 12),
                        child: Icon(Icons.search, color: AppColors.primary)),
                    const Expanded(child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search products...',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                        hintStyle: TextStyle(color: AppColors.greyText, fontSize: 13)),
                    )),
                    IconButton(icon: const Icon(Icons.tune, color: AppColors.primary), onPressed: () {}),
                  ]),
                ),
              ),
              // Banner
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: SizedBox(
                    height: 150,
                    child: Stack(fit: StackFit.expand, children: [
                      Image.network('https://images.unsplash.com/photo-1445205170230-053b83016050?w=700&h=300&fit=crop',
                          fit: BoxFit.cover,
                          errorBuilder: (c,e,s) => Container(color: AppColors.primaryDark)),
                      Container(color: Colors.black.withOpacity(0.45)),
                      Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center, children: [
                          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(20)),
                            child: const Text('NEW ARRIVALS', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700))),
                          const SizedBox(height: 6),
                          const Text('Summer Sale\nUp to 40% OFF', style: TextStyle(
                              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, height: 1.25)),
                          const SizedBox(height: 10),
                          Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                            child: const Text('Shop Now →', style: TextStyle(color: AppColors.primary, fontSize: 11, fontWeight: FontWeight.w700))),
                        ]),
                      ),
                    ]),
                  ),
                ),
              ),
              // Categories
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 20, 16, 10),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Categories', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  Text('See all', style: TextStyle(color: AppColors.primary, fontSize: 12)),
                ]),
              ),
              SizedBox(
                height: 88,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: categories.length,
                  itemBuilder: (context, i) => Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Column(children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.network(categories[i]['img']!,
                          width: 54, height: 54, fit: BoxFit.cover,
                          errorBuilder: (c, e, s) => Container(width: 54, height: 54,
                              color: AppColors.primaryLight,
                              child: const Icon(Icons.category_outlined, color: AppColors.primary, size: 26))),
                      ),
                      const SizedBox(height: 4),
                      Text(categories[i]['name']!, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w500)),
                    ]),
                  ),
                ),
              ),
              // Featured Products from Firestore
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 10),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Featured Products', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  Text('See all', style: TextStyle(color: AppColors.primary, fontSize: 12)),
                ]),
              ),
              Consumer<ProductsProvider>(
                builder: (_, prods, __) {
                  if (prods.loading) {
                    return const Padding(padding: EdgeInsets.all(30),
                      child: Center(child: CircularProgressIndicator(color: AppColors.primary)));
                  }
                  final products = prods.products;
                  if (products.isEmpty) return const SizedBox.shrink();
                  return GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, childAspectRatio: 0.7,
                      crossAxisSpacing: 12, mainAxisSpacing: 12),
                    itemCount: products.length,
                    itemBuilder: (context, i) => ProductCard(
                      product: products[i],
                      onTap: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => ProductDetailScreen(product: products[i]))),
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
            ]),
          ),
        ],
      ),
    );
  }
}