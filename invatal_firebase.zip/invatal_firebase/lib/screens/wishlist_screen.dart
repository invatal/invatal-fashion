
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/app_theme.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';
import '../providers/wishlist_provider.dart';
import '../providers/products_provider.dart';
import 'product_detail_screen.dart';

class WishlistScreen extends StatefulWidget {
  const WishlistScreen({super.key});
  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<WishlistProvider>().listenToWishlist();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Wishlist')),
      body: Consumer2<WishlistProvider, ProductsProvider>(
        builder: (_, wishlist, prods, __) {
          final wishlistIds = wishlist.wishlistIds;
          final wishlisted = prods.products.where((p) => wishlistIds.contains(p.id)).toList();

          if (wishlisted.isEmpty) {
            return const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('❤️', style: TextStyle(fontSize: 60)),
              SizedBox(height: 12),
              Text('Your wishlist is empty', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.greyText)),
            ]));
          }
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, childAspectRatio: 0.68, crossAxisSpacing: 12, mainAxisSpacing: 12),
            itemCount: wishlisted.length,
            itemBuilder: (context, i) => ProductCard(
              product: wishlisted[i],
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => ProductDetailScreen(product: wishlisted[i])))),
          );
        },
      ),
    );
  }
}
