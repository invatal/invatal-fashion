
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/app_theme.dart';
import '../providers/cart_provider.dart';
import '../services/firestore_service.dart';
import '../models/order_model.dart';
import 'order_success_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  int _step = 0;
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _addr1Ctrl = TextEditingController();
  final _addr2Ctrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _postalCtrl = TextEditingController();
  String _delivery = 'Standard Delivery (Free)';
  String _payment = 'Cash on Delivery';
  bool _loading = false;

  @override
  void dispose() {
    _nameCtrl.dispose(); _phoneCtrl.dispose(); _addr1Ctrl.dispose();
    _addr2Ctrl.dispose(); _cityCtrl.dispose(); _postalCtrl.dispose();
    super.dispose();
  }

  Future<void> _placeOrder() async {
    setState(() => _loading = true);
    try {
      final cart = context.read<CartProvider>();
      final fs = FirestoreService();
      final deliveryFee = _delivery.contains('Express') ? 300.0 : 0.0;

      final order = OrderModel(
        id: '',
        userId: '',
        items: cart.items.map((item) => OrderItem(
          productId: item.productId,
          name: item.name,
          price: item.price,
          imageUrl: item.imageUrl,
          qty: item.qty,
          size: item.size,
          color: item.color,
        )).toList(),
        subtotal: cart.subtotal,
        deliveryFee: deliveryFee,
        total: cart.subtotal + deliveryFee,
        status: 'Processing',
        deliveryAddress: '${_addr1Ctrl.text}, ${_addr2Ctrl.text}'.trim().replaceAll(', ,', ','),
        city: _cityCtrl.text.isEmpty ? 'Colombo' : _cityCtrl.text,
        phone: _phoneCtrl.text.isEmpty ? '+94 00 000 0000' : _phoneCtrl.text,
        paymentMethod: _payment,
      );

      final orderId = await fs.placeOrder(order);
      setState(() => _loading = false);

      if (mounted) {
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => OrderSuccessScreen(orderId: orderId, total: order.total)));
      }
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}'), backgroundColor: Colors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: Column(children: [
        // Step indicator
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          child: Row(children: [
            _StepCircle(num: 1, label: 'Address', active: _step >= 0, done: _step > 0),
            Expanded(child: Container(height: 2, color: _step > 0 ? AppColors.primary : const Color(0xFFE0E0E0))),
            _StepCircle(num: 2, label: 'Payment', active: _step >= 1, done: _step > 1),
            Expanded(child: Container(height: 2, color: _step > 1 ? AppColors.primary : const Color(0xFFE0E0E0))),
            _StepCircle(num: 3, label: 'Review', active: _step >= 2, done: false),
          ]),
        ),
        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (_step == 0) ...[
                const Text('Delivery Address', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                const SizedBox(height: 14),
                _field(_nameCtrl, 'Full Name', Icons.person_outline),
                _field(_phoneCtrl, 'Phone Number', Icons.phone_outlined, type: TextInputType.phone),
                _field(_addr1Ctrl, 'Address Line 1', Icons.home_outlined),
                _field(_addr2Ctrl, 'Address Line 2 (Optional)', Icons.apartment, required: false),
                Row(children: [
                  Expanded(child: _field(_cityCtrl, 'City', Icons.location_city)),
                  const SizedBox(width: 10),
                  Expanded(child: _field(_postalCtrl, 'Postal Code', Icons.local_post_office, type: TextInputType.number)),
                ]),
                const SizedBox(height: 8),
                const Text('Delivery Method', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                ...['Standard Delivery (Free)', 'Express Delivery (LKR 300)'].map((opt) =>
                  RadioListTile<String>(
                    value: opt, groupValue: _delivery,
                    onChanged: (v) => setState(() => _delivery = v!),
                    title: Text(opt, style: const TextStyle(fontSize: 13)),
                    activeColor: AppColors.primary, contentPadding: EdgeInsets.zero)),
              ],
              if (_step == 1) ...[
                const Text('Payment Method', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                const SizedBox(height: 14),
                ...['Cash on Delivery', 'Credit / Debit Card', 'Bank Transfer'].map((opt) =>
                  RadioListTile<String>(
                    value: opt, groupValue: _payment,
                    onChanged: (v) => setState(() => _payment = v!),
                    title: Text(opt, style: const TextStyle(fontSize: 13)),
                    activeColor: AppColors.primary, contentPadding: EdgeInsets.zero)),
                if (_payment == 'Credit / Debit Card') ...[
                  const SizedBox(height: 12),
                  _field(TextEditingController(), 'Card Number', Icons.credit_card, type: TextInputType.number, required: false),
                  Row(children: [
                    Expanded(child: _field(TextEditingController(), 'Expiry (MM/YY)', Icons.date_range, required: false)),
                    const SizedBox(width: 10),
                    Expanded(child: _field(TextEditingController(), 'CVV', Icons.lock_outline, required: false)),
                  ]),
                ],
              ],
              if (_step == 2) ...[
                const Text('Order Review', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                const SizedBox(height: 14),
                _ReviewRow('Name', _nameCtrl.text.isEmpty ? 'Customer' : _nameCtrl.text),
                _ReviewRow('Phone', _phoneCtrl.text.isEmpty ? 'N/A' : _phoneCtrl.text),
                _ReviewRow('Address', '${_addr1Ctrl.text.isEmpty ? "N/A" : _addr1Ctrl.text}, ${_cityCtrl.text.isEmpty ? "" : _cityCtrl.text}'),
                _ReviewRow('Delivery', _delivery),
                _ReviewRow('Payment', _payment),
                const Divider(height: 24),
                const Text('Order Summary', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                Consumer<CartProvider>(
                  builder: (_, cart, __) => Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFFFAFAFA), borderRadius: BorderRadius.circular(10)),
                    child: Column(children: [
                      _SumLine('Subtotal (${cart.itemCount} items)', 'LKR ${cart.subtotal.toStringAsFixed(0)}'),
                      _SumLine('Delivery', _delivery.contains('Express') ? 'LKR 300' : 'Free'),
                      const Divider(),
                      _SumLine('Total',
                          'LKR ${(cart.subtotal + (_delivery.contains('Express') ? 300 : 0)).toStringAsFixed(0)}',
                          bold: true),
                    ]),
                  ),
                ),
              ],
            ]),
          ),
        )),
        Padding(
          padding: const EdgeInsets.all(16),
          child: ElevatedButton(
            onPressed: _loading ? null : () async {
              if (_step < 2) {
                if (_step == 0 && !(_formKey.currentState?.validate() ?? false)) return;
                setState(() => _step++);
              } else {
                await _placeOrder();
              }
            },
            child: _loading
                ? const SizedBox(height: 20, width: 20,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Text(_step == 0 ? 'Continue to Payment →' : _step == 1 ? 'Review Order →' : 'Place Order 🎉'),
          ),
        ),
      ]),
    );
  }

  Widget _field(TextEditingController ctrl, String label, IconData icon,
      {TextInputType type = TextInputType.text, bool required = true}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: ctrl, keyboardType: type,
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon, color: AppColors.primary, size: 20)),
        validator: required ? (v) => v == null || v.isEmpty ? 'Required' : null : null,
      ),
    );
  }

  Widget _ReviewRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 80, child: Text(label, style: const TextStyle(color: AppColors.greyText, fontSize: 12))),
      Expanded(child: Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500))),
    ]),
  );
}

class _StepCircle extends StatelessWidget {
  final int num;
  final String label;
  final bool active, done;
  const _StepCircle({required this.num, required this.label, required this.active, required this.done});
  @override
  Widget build(BuildContext context) => Column(children: [
    Container(width: 30, height: 30,
      decoration: BoxDecoration(color: active ? AppColors.primary : const Color(0xFFE0E0E0), shape: BoxShape.circle),
      child: Center(child: done
          ? const Icon(Icons.check, color: Colors.white, size: 16)
          : Text('$num', style: TextStyle(color: active ? Colors.white : AppColors.greyText,
              fontSize: 13, fontWeight: FontWeight.w700)))),
    const SizedBox(height: 4),
    Text(label, style: TextStyle(fontSize: 10,
        color: active ? AppColors.primary : AppColors.greyText,
        fontWeight: active ? FontWeight.w600 : FontWeight.w400)),
  ]);
}

class _SumLine extends StatelessWidget {
  final String label, value;
  final bool bold;
  const _SumLine(this.label, this.value, {this.bold = false});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(fontSize: 13,
          fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
          color: bold ? AppColors.darkText : AppColors.greyText)),
      Text(value, style: TextStyle(fontSize: bold ? 15 : 13,
          fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
          color: AppColors.darkText)),
    ]),
  );
}
