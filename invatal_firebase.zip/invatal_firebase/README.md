# Invatal Fashion Store — Firebase Backend

CIT211 Mobile Software Development — Phase 2 (Firebase Integration)

## 🔧 Firebase Setup (Required Before Running)

### Step 1: Create Firebase Project
1. Go to https://console.firebase.google.com
2. Click "Add Project" → Name: `invatal-fashion`
3. Disable Google Analytics → Create Project

### Step 2: Enable Authentication
1. Firebase Console → Authentication → Get Started
2. Sign-in method → Email/Password → Enable → Save

### Step 3: Enable Firestore
1. Firebase Console → Firestore Database → Create Database
2. Start in **test mode** → Choose region (e.g. asia-south1) → Done

### Step 4: Enable Storage
1. Firebase Console → Storage → Get Started
2. Start in test mode → Done

### Step 5: Add Android App
1. Firebase Console → Project Settings → Add App → Android
2. Package name: `com.invatal.fashion`
3. Download `google-services.json`
4. Place it at: `android/app/google-services.json`

### Step 6: Install FlutterFire CLI & Configure
```bash
dart pub global activate flutterfire_cli
flutterfire configure --project=YOUR_PROJECT_ID
```
This auto-generates `lib/firebase_options.dart` with correct values.

**OR manually edit `lib/firebase_options.dart`** and replace:
- `YOUR_ANDROID_API_KEY` → from google-services.json (api_key[0].current_key)
- `YOUR_PROJECT_ID` → your Firebase project ID
- `YOUR_PROJECT_NUMBER` → project_number from google-services.json
- `YOUR_APP_ID` → client[0].client_info.mobilesdk_app_id

---

## 🚀 Run the App

```bash
flutter pub get
flutter run
```

## 📦 Build Release APK

```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

---

## 🏗 Architecture

```
lib/
├── main.dart                    # App entry + MultiProvider setup
├── firebase_options.dart        # Firebase config (replace values)
├── models/
│   ├── product.dart             # Product model + sample data
│   ├── cart.dart                # Local cart model
│   └── order_model.dart         # Order + OrderItem models
├── services/
│   ├── firebase_auth_service.dart  # Auth: register/login/signout/reset
│   └── firestore_service.dart      # Firestore: products/cart/wishlist/orders
├── providers/
│   ├── auth_provider.dart       # Auth state management
│   ├── cart_provider.dart       # Cart state (real-time Firestore)
│   ├── wishlist_provider.dart   # Wishlist state (real-time Firestore)
│   └── products_provider.dart   # Products (Firestore + local fallback)
├── screens/                     # All 12 UI screens
├── widgets/
│   └── product_card.dart
└── utils/
    └── app_theme.dart
```

## 🔥 Firebase Features

| Feature | Implementation |
|---|---|
| Authentication | Email/Password via `firebase_auth` |
| User Profiles | Stored in `users/{uid}` Firestore collection |
| Products | `products` collection (auto-seeded on first run) |
| Cart | `users/{uid}/cart` sub-collection, real-time |
| Wishlist | `users/{uid}/wishlist` sub-collection, real-time |
| Orders | `orders` collection + `users/{uid}/orders` reference |
| Password Reset | Firebase Auth email reset |
| Auth Persistence | Automatic (user stays logged in) |

## 🔒 Firestore Security Rules (Production)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /products/{doc} {
      allow read: if true;
      allow write: if false;
    }
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
      match /{sub}/{doc} {
        allow read, write: if request.auth != null && request.auth.uid == uid;
      }
    }
    match /orders/{orderId} {
      allow read: if request.auth != null && resource.data.userId == request.auth.uid;
      allow create: if request.auth != null;
    }
  }
}
```

## Packages Used
- `firebase_core: ^3.8.0`
- `firebase_auth: ^5.3.4`
- `cloud_firestore: ^5.5.0`
- `firebase_storage: ^12.3.6`
- `provider: ^6.1.2`
